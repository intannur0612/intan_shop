const PRODUCT_IMAGE_VARIANTS = {
  ring: [
    "images/WhatsApp Image 2026-07-09 at 08.37.10 (1).jpeg=",
    "images/WhatsApp Image 2026-07-09 at 08.37.10.jpeg",
    "images/WhatsApp Image 2026-07-09 at 08.37.11 (1).jpeg",
    "images/WhatsApp Image 2026-07-09 at 08.37.11 (2).jpeg",
  ],
  bracelet: [
    "images/WhatsApp Image 2026-07-09 at 08.54.14 (1).jpeg",
    "images/WhatsApp Image 2026-07-09 at 08.54.14 (2).jpeg",
    "images/WhatsApp Image 2026-07-09 at 08.54.14.jpeg",
    "images/WhatsApp Image 2026-07-09 at 08.54.15.jpeg",
  ],
  necklace: [
    "images/WhatsApp Image 2026-07-09 at 09.00.37 (1).jpeg",
    "images/WhatsApp Image 2026-07-09 at 09.00.37.jpeg",
    "images/WhatsApp Image 2026-07-09 at 09.00.38 (1).jpeg",
    "images/WhatsApp Image 2026-07-09 at 09.00.38.jpeg",
  ],
  pendant: [
    "images/WhatsApp Image 2026-07-09 at 09.06.31.jpeg",
    "images/WhatsApp Image 2026-07-09 at 09.06.32 (1).jpeg",
    "images/WhatsApp Image 2026-07-09 at 09.06.32.jpeg",
  ],
  diamond: [
    "images/WhatsApp Image 2026-07-09 at 09.11.29.jpeg",
    "images/WhatsApp Image 2026-07-09 at 09.11.30 (1).jpeg",
    "images/WhatsApp Image 2026-07-09 at 09.11.30.jpeg",
  ],
  earring: [
    "images/WhatsApp Image 2026-07-09 at 09.17.52.jpeg",
    "images/WhatsApp Image 2026-07-09 at 09.17.53 (1).jpeg",
    "images/WhatsApp Image 2026-07-09 at 09.17.53.jpeg",
  ],
  watch: [
    "images/WhatsApp Image 2026-07-09 at 09.22.21 (1).jpeg",
    "images/WhatsApp Image 2026-07-09 at 09.22.21 (2).jpeg",
    "images/WhatsApp Image 2026-07-09 at 09.22.21.jpeg",
  ],
  bag: [
    "images/WhatsApp Image 2026-07-09 at 09.26.19 (1).jpeg",
    "images/WhatsApp Image 2026-07-09 at 09.26.19 (2).jpeg",
    "images/WhatsApp Image 2026-07-09 at 09.26.19.jpeg",
  ],
  gift: [
    "images/WhatsApp Image 2026-07-09 at 09.30.13.jpeg",
    "images/WhatsApp Image 2026-07-09 at 09.30.14 (1).jpeg",
    "images/WhatsApp Image 2026-07-09 at 09.30.14.jpeg",
  ],
  gold: [
    "images/WhatsApp Image 2026-07-09 at 09.33.44 (1).jpeg",
    "images/WhatsApp Image 2026-07-09 at 09.33.44 (2).jpeg",
    "images/WhatsApp Image 2026-07-09 at 09.33.44.jpeg",
  ],
  default: [
    "https://images.unsplash.com/photo-1512436991641-6745cdb1723f?auto=format&fit=crop&w=1200&q=80",
  ],
};

function getProductImage(product, index = 0) {
  const name = product.name.toLowerCase();
  const category = product.category.toLowerCase();

  if (name.includes("ring") || name.includes("cincin"))
    return PRODUCT_IMAGE_VARIANTS.ring[
      index % PRODUCT_IMAGE_VARIANTS.ring.length
    ];
  if (
    name.includes("bracelet") ||
    name.includes("cuff") ||
    name.includes("bangle") ||
    name.includes("gelang")
  )
    return PRODUCT_IMAGE_VARIANTS.bracelet[
      index % PRODUCT_IMAGE_VARIANTS.bracelet.length
    ];
  if (
    name.includes("necklace") ||
    name.includes("choker") ||
    name.includes("pendant") ||
    name.includes("collar") ||
    name.includes("kalung")
  )
    return PRODUCT_IMAGE_VARIANTS.necklace[
      index % PRODUCT_IMAGE_VARIANTS.necklace.length
    ];
  if (
    name.includes("earring") ||
    name.includes("drop") ||
    name.includes("anting")
  )
    return PRODUCT_IMAGE_VARIANTS.earring[
      index % PRODUCT_IMAGE_VARIANTS.earring.length
    ];
  if (name.includes("watch") || name.includes("jam"))
    return PRODUCT_IMAGE_VARIANTS.watch[
      index % PRODUCT_IMAGE_VARIANTS.watch.length
    ];
  if (name.includes("bag") || name.includes("tote") || name.includes("tas"))
    return PRODUCT_IMAGE_VARIANTS.bag[
      index % PRODUCT_IMAGE_VARIANTS.bag.length
    ];
  if (
    name.includes("gift") ||
    name.includes("box") ||
    name.includes("set") ||
    name.includes("hadiah")
  )
    return PRODUCT_IMAGE_VARIANTS.gift[
      index % PRODUCT_IMAGE_VARIANTS.gift.length
    ];
  if (name.includes("pearl") || name.includes("mutiara"))
    return PRODUCT_IMAGE_VARIANTS.pendant[
      index % PRODUCT_IMAGE_VARIANTS.pendant.length
    ];
  if (
    category.includes("gold") ||
    name.includes("gold") ||
    name.includes("golden") ||
    name.includes("rose gold")
  )
    return PRODUCT_IMAGE_VARIANTS.gold[
      index % PRODUCT_IMAGE_VARIANTS.gold.length
    ];
  if (
    category.includes("diamond") ||
    name.includes("diamond") ||
    name.includes("halo") ||
    name.includes("solitaire") ||
    name.includes("emerald") ||
    name.includes("ruby")
  )
    return PRODUCT_IMAGE_VARIANTS.diamond[
      index % PRODUCT_IMAGE_VARIANTS.diamond.length
    ];
  return PRODUCT_IMAGE_VARIANTS.default[
    index % PRODUCT_IMAGE_VARIANTS.default.length
  ];
}

function getProductGallery(product, count = 3) {
  return Array.from({ length: count }, (_, index) =>
    getProductImage(product, index + (product.id.length % 2)),
  );
}

const PRODUCTS_DATA = [
  {
    id: "diamond-01",
    name: "Diamond Halo Pendant",
    category: "Diamond",
    price: 18500000,
    discount: 12,
    rating: 4.9,
    reviews: 128,
    stock: 12,
    sku: "DIA-001",
    badge: "New",
    image:
      "https://images.unsplash.com/photo-1617038260897-41a1f14a8ca0?auto=format&fit=crop&w=800&q=80",
    description: "Pendant berlian presisi tinggi dengan setting rose gold.",
  },
  {
    id: "diamond-02",
    name: "Solitaire Ring",
    category: "Diamond",
    price: 14500000,
    discount: 8,
    rating: 4.8,
    reviews: 94,
    stock: 8,
    sku: "DIA-002",
    badge: "Best Seller",
    image:
      "https://images.unsplash.com/photo-1617038260897-41a1f14a8ca0?auto=format&fit=crop&w=800&q=80",
    description: "Cincin solitaire dengan berlian 1 karat.",
  },
  {
    id: "diamond-03",
    name: "Eternity Bracelet",
    category: "Diamond",
    price: 9800000,
    discount: 10,
    rating: 4.7,
    reviews: 74,
    stock: 6,
    sku: "DIA-003",
    badge: "Limited",
    image:
      "https://images.unsplash.com/photo-1515562141207-7a88fb7ce338?auto=format&fit=crop&w=800&q=80",
    description: "Gelang berlian menawan dan elegan.",
  },
  {
    id: "diamond-04",
    name: "Diamond Drop Earrings",
    category: "Diamond",
    price: 7200000,
    discount: 5,
    rating: 4.6,
    reviews: 57,
    stock: 14,
    sku: "DIA-004",
    badge: "Hot",
    image:
      "https://images.unsplash.com/photo-1617038260897-41a1f14a8ca0?auto=format&fit=crop&w=800&q=80",
    description: "Anting drop berlian dengan kilau elegan.",
  },
  {
    id: "diamond-05",
    name: "Diamond Tennis Necklace",
    category: "Diamond",
    price: 15600000,
    discount: 15,
    rating: 4.9,
    reviews: 103,
    stock: 5,
    sku: "DIA-005",
    badge: "New",
    image:
      "https://images.unsplash.com/photo-1617038260897-41a1f14a8ca0?auto=format&fit=crop&w=800&q=80",
    description: "Kalung berlian dengan susunan simetris premium.",
  },
  {
    id: "diamond-06",
    name: "Oval Diamond Ring",
    category: "Diamond",
    price: 13200000,
    discount: 7,
    rating: 4.7,
    reviews: 88,
    stock: 7,
    sku: "DIA-006",
    badge: "Best Seller",
    image:
      "https://images.unsplash.com/photo-1617038260897-41a1f14a8ca0?auto=format&fit=crop&w=800&q=80",
    description: "Cincin berlian oval modern dan eksklusif.",
  },
  {
    id: "diamond-07",
    name: "Diamond Cuff Bracelet",
    category: "Diamond",
    price: 8900000,
    discount: 6,
    rating: 4.8,
    reviews: 63,
    stock: 9,
    sku: "DIA-007",
    badge: "Hot",
    image:
      "https://images.unsplash.com/photo-1515562141207-7a88fb7ce338?auto=format&fit=crop&w=800&q=80",
    description: "Cuff bracelet dengan batu permata bertatah.",
  },
  {
    id: "diamond-08",
    name: "Marquise Diamond Set",
    category: "Diamond",
    price: 17200000,
    discount: 13,
    rating: 4.9,
    reviews: 117,
    stock: 4,
    sku: "DIA-008",
    badge: "Limited",
    image:
      "https://images.unsplash.com/photo-1617038260897-41a1f14a8ca0?auto=format&fit=crop&w=800&q=80",
    description: "Set perhiasan eksklusif marquise.",
  },
  {
    id: "gold-01",
    name: "Gold Pearl Collar",
    category: "Gold Jewelry",
    price: 7800000,
    discount: 9,
    rating: 4.6,
    reviews: 61,
    stock: 11,
    sku: "GOL-001",
    badge: "New",
    image:
      "https://images.unsplash.com/photo-1617038260897-41a1f14a8ca0?auto=format&fit=crop&w=800&q=80",
    description: "Kalung emas dengan aksen mutiara mewah.",
  },
  {
    id: "gold-02",
    name: "Rose Gold Bangle",
    category: "Gold Jewelry",
    price: 4200000,
    discount: 8,
    rating: 4.5,
    reviews: 42,
    stock: 15,
    sku: "GOL-002",
    badge: "Best Seller",
    image:
      "https://images.unsplash.com/photo-1515562141207-7a88fb7ce338?auto=format&fit=crop&w=800&q=80",
    description: "Gelang rose gold dengan finish lembut.",
  },
  {
    id: "gold-03",
    name: "Gold Chain Earrings",
    category: "Gold Jewelry",
    price: 3600000,
    discount: 5,
    rating: 4.4,
    reviews: 35,
    stock: 17,
    sku: "GOL-003",
    badge: "Hot",
    image:
      "https://images.unsplash.com/photo-1617038260897-41a1f14a8ca0?auto=format&fit=crop&w=800&q=80",
    description: "Anting rantai emas yang modern.",
  },
  {
    id: "gold-04",
    name: "Gold Signet Ring",
    category: "Gold Jewelry",
    price: 5100000,
    discount: 6,
    rating: 4.7,
    reviews: 52,
    stock: 10,
    sku: "GOL-004",
    badge: "Limited",
    image:
      "https://images.unsplash.com/photo-1617038260897-41a1f14a8ca0?auto=format&fit=crop&w=800&q=80",
    description: "Cincin signet klasik dengan detail premium.",
  },
  {
    id: "gold-05",
    name: "Gold Ombre Bracelet",
    category: "Gold Jewelry",
    price: 4700000,
    discount: 10,
    rating: 4.6,
    reviews: 46,
    stock: 13,
    sku: "GOL-005",
    badge: "New",
    image:
      "https://images.unsplash.com/photo-1515562141207-7a88fb7ce338?auto=format&fit=crop&w=800&q=80",
    description: "Gelang emas dengan desain ombre.",
  },
  {
    id: "gold-06",
    name: "Gold Twist Necklace",
    category: "Gold Jewelry",
    price: 5900000,
    discount: 7,
    rating: 4.8,
    reviews: 68,
    stock: 8,
    sku: "GOL-006",
    badge: "Best Seller",
    image:
      "https://images.unsplash.com/photo-1617038260897-41a1f14a8ca0?auto=format&fit=crop&w=800&q=80",
    description: "Kalung emas twist dengan sentuhan modern.",
  },
  {
    id: "gold-07",
    name: "Gold Huggie Set",
    category: "Gold Jewelry",
    price: 3100000,
    discount: 5,
    rating: 4.5,
    reviews: 39,
    stock: 16,
    sku: "GOL-007",
    badge: "Hot",
    image:
      "https://images.unsplash.com/photo-1617038260897-41a1f14a8ca0?auto=format&fit=crop&w=800&q=80",
    description: "Set anting huggie mengkilap dan ringan.",
  },
  {
    id: "gold-08",
    name: "Gold Layered Ring",
    category: "Gold Jewelry",
    price: 4400000,
    discount: 9,
    rating: 4.7,
    reviews: 59,
    stock: 9,
    sku: "GOL-008",
    badge: "Limited",
    image:
      "https://images.unsplash.com/photo-1617038260897-41a1f14a8ca0?auto=format&fit=crop&w=800&q=80",
    description: "Cincin layered gold untuk look glam.",
  },
  {
    id: "ring-01",
    name: "Luna Diamond Ring",
    category: "Ring",
    price: 8600000,
    discount: 11,
    rating: 4.8,
    reviews: 72,
    stock: 7,
    sku: "RNG-001",
    badge: "New",
    image:
      "https://images.unsplash.com/photo-1617038260897-41a1f14a8ca0?auto=format&fit=crop&w=800&q=80",
    description: "Cincin modern dengan motif bulan.",
  },
  {
    id: "ring-02",
    name: "Velvet Gold Ring",
    category: "Ring",
    price: 3100000,
    discount: 6,
    rating: 4.5,
    reviews: 41,
    stock: 12,
    sku: "RNG-002",
    badge: "Best Seller",
    image:
      "https://images.unsplash.com/photo-1617038260897-41a1f14a8ca0?auto=format&fit=crop&w=800&q=80",
    description: "Cincin gold klasik dengan detail halus.",
  },
  {
    id: "ring-03",
    name: "Platinum Stack Ring",
    category: "Ring",
    price: 6400000,
    discount: 8,
    rating: 4.7,
    reviews: 53,
    stock: 10,
    sku: "RNG-003",
    badge: "Hot",
    image:
      "https://images.unsplash.com/photo-1617038260897-41a1f14a8ca0?auto=format&fit=crop&w=800&q=80",
    description: "Cincin platina stacking eksklusif.",
  },
  {
    id: "ring-04",
    name: "Emerald Halo Ring",
    category: "Ring",
    price: 7800000,
    discount: 10,
    rating: 4.8,
    reviews: 67,
    stock: 6,
    sku: "RNG-004",
    badge: "Limited",
    image:
      "https://images.unsplash.com/photo-1617038260897-41a1f14a8ca0?auto=format&fit=crop&w=800&q=80",
    description: "Cincin emerald halo berkelas tinggi.",
  },
  {
    id: "ring-05",
    name: "Sculptural Ring",
    category: "Ring",
    price: 2900000,
    discount: 4,
    rating: 4.4,
    reviews: 29,
    stock: 14,
    sku: "RNG-005",
    badge: "Hot",
    image:
      "https://images.unsplash.com/photo-1617038260897-41a1f14a8ca0?auto=format&fit=crop&w=800&q=80",
    description: "Desain cincin artistik untuk sentuhan modern.",
  },
  {
    id: "ring-06",
    name: "Ruby Glow Ring",
    category: "Ring",
    price: 5200000,
    discount: 7,
    rating: 4.6,
    reviews: 44,
    stock: 11,
    sku: "RNG-006",
    badge: "Best Seller",
    image:
      "https://images.unsplash.com/photo-1617038260897-41a1f14a8ca0?auto=format&fit=crop&w=800&q=80",
    description: "Cincin ruby glow dengan kilau tajam.",
  },
  {
    id: "bracelet-01",
    name: "Ivory Diamond Bracelet",
    category: "Bracelet",
    price: 6400000,
    discount: 9,
    rating: 4.7,
    reviews: 58,
    stock: 8,
    sku: "BRC-001",
    badge: "New",
    image:
      "https://images.unsplash.com/photo-1515562141207-7a88fb7ce338?auto=format&fit=crop&w=800&q=80",
    description: "Gelang diamond dengan nuansa ivory.",
  },
  {
    id: "bracelet-02",
    name: "Golden Cascade Bracelet",
    category: "Bracelet",
    price: 4100000,
    discount: 8,
    rating: 4.5,
    reviews: 37,
    stock: 12,
    sku: "BRC-002",
    badge: "Best Seller",
    image:
      "https://images.unsplash.com/photo-1515562141207-7a88fb7ce338?auto=format&fit=crop&w=800&q=80",
    description: "Desain cascade fleksibel dengan warna gold.",
  },
  {
    id: "bracelet-03",
    name: "Pearl Cuff Bracelet",
    category: "Bracelet",
    price: 3300000,
    discount: 5,
    rating: 4.4,
    reviews: 31,
    stock: 10,
    sku: "BRC-003",
    badge: "Hot",
    image:
      "https://images.unsplash.com/photo-1515562141207-7a88fb7ce338?auto=format&fit=crop&w=800&q=80",
    description: "Cuff bracelet pearl yang minimalis.",
  },
  {
    id: "bracelet-04",
    name: "Aurora Bracelet",
    category: "Bracelet",
    price: 3600000,
    discount: 7,
    rating: 4.6,
    reviews: 42,
    stock: 9,
    sku: "BRC-004",
    badge: "Limited",
    image:
      "https://images.unsplash.com/photo-1515562141207-7a88fb7ce338?auto=format&fit=crop&w=800&q=80",
    description: "Desain bracelet dengan aksen aurora.",
  },
  {
    id: "bracelet-05",
    name: "Crystal Link Bracelet",
    category: "Bracelet",
    price: 2800000,
    discount: 4,
    rating: 4.3,
    reviews: 26,
    stock: 15,
    sku: "BRC-005",
    badge: "Hot",
    image:
      "https://images.unsplash.com/photo-1515562141207-7a88fb7ce338?auto=format&fit=crop&w=800&q=80",
    description: "Gelang link crystal dengan kilau lembut.",
  },
  {
    id: "bracelet-06",
    name: "Velour Gold Bracelet",
    category: "Bracelet",
    price: 3850000,
    discount: 6,
    rating: 4.5,
    reviews: 34,
    stock: 11,
    sku: "BRC-006",
    badge: "Best Seller",
    image:
      "https://images.unsplash.com/photo-1515562141207-7a88fb7ce338?auto=format&fit=crop&w=800&q=80",
    description: "Gelang gold dengan sentuhan velour elegan.",
  },
  {
    id: "necklace-01",
    name: "Luxe Heart Necklace",
    category: "Necklace",
    price: 5200000,
    discount: 8,
    rating: 4.6,
    reviews: 48,
    stock: 13,
    sku: "NCK-001",
    badge: "New",
    image:
      "https://images.unsplash.com/photo-1617038260897-41a1f14a8ca0?auto=format&fit=crop&w=800&q=80",
    description: "Kalung hati dengan desain modern.",
  },
  {
    id: "necklace-02",
    name: "Diamond Choker",
    category: "Necklace",
    price: 7100000,
    discount: 10,
    rating: 4.8,
    reviews: 64,
    stock: 7,
    sku: "NCK-002",
    badge: "Best Seller",
    image:
      "https://images.unsplash.com/photo-1617038260897-41a1f14a8ca0?auto=format&fit=crop&w=800&q=80",
    description: "Choker berlian dengan kesan glam.",
  },
  {
    id: "necklace-03",
    name: "Auric Pendant",
    category: "Necklace",
    price: 4600000,
    discount: 7,
    rating: 4.5,
    reviews: 40,
    stock: 12,
    sku: "NCK-003",
    badge: "Hot",
    image:
      "https://images.unsplash.com/photo-1617038260897-41a1f14a8ca0?auto=format&fit=crop&w=800&q=80",
    description: "Pendant auric menggabungkan logam premium.",
  },
  {
    id: "necklace-04",
    name: "Opal Halo Necklace",
    category: "Necklace",
    price: 6100000,
    discount: 9,
    rating: 4.7,
    reviews: 56,
    stock: 8,
    sku: "NCK-004",
    badge: "Limited",
    image:
      "https://images.unsplash.com/photo-1617038260897-41a1f14a8ca0?auto=format&fit=crop&w=800&q=80",
    description: "Kalung opal halo berkelas eksklusif.",
  },
  {
    id: "necklace-05",
    name: "Baroque Chain",
    category: "Necklace",
    price: 3600000,
    discount: 5,
    rating: 4.4,
    reviews: 32,
    stock: 14,
    sku: "NCK-005",
    badge: "Hot",
    image:
      "https://images.unsplash.com/photo-1617038260897-41a1f14a8ca0?auto=format&fit=crop&w=800&q=80",
    description: "Rantai baroque dengan desain klasik.",
  },
  {
    id: "necklace-06",
    name: "Noir Pendant",
    category: "Necklace",
    price: 4300000,
    discount: 6,
    rating: 4.6,
    reviews: 38,
    stock: 11,
    sku: "NCK-006",
    badge: "Best Seller",
    image:
      "https://images.unsplash.com/photo-1617038260897-41a1f14a8ca0?auto=format&fit=crop&w=800&q=80",
    description: "Kalung noir minimalis berkarakter.",
  },
  {
    id: "bag-01",
    name: "Monogram Silk Bag",
    category: "Luxury Bag",
    price: 14500000,
    discount: 12,
    rating: 4.9,
    reviews: 88,
    stock: 5,
    sku: "BAG-001",
    badge: "Best Seller",
    image:
      "https://images.unsplash.com/photo-1584917865442-de89df76afd3?auto=format&fit=crop&w=800&q=80",
    description: "Tas luxury dengan monogram premium.",
  },
  {
    id: "bag-02",
    name: "Rose Gold Tote",
    category: "Luxury Bag",
    price: 9800000,
    discount: 7,
    rating: 4.7,
    reviews: 57,
    stock: 6,
    sku: "BAG-002",
    badge: "New",
    image:
      "https://images.unsplash.com/photo-1584917865442-de89df76afd3?auto=format&fit=crop&w=800&q=80",
    description: "Tote emas rose gold untuk suasana glam.",
  },
  {
    id: "bag-03",
    name: "Velvet Mini Bag",
    category: "Luxury Bag",
    price: 7600000,
    discount: 8,
    rating: 4.6,
    reviews: 49,
    stock: 8,
    sku: "BAG-003",
    badge: "Hot",
    image:
      "https://images.unsplash.com/photo-1584917865442-de89df76afd3?auto=format&fit=crop&w=800&q=80",
    description: "Tas mini velvet untuk acara malam.",
  },
  {
    id: "bag-04",
    name: "Crown Structured Bag",
    category: "Luxury Bag",
    price: 11200000,
    discount: 10,
    rating: 4.8,
    reviews: 71,
    stock: 4,
    sku: "BAG-004",
    badge: "Limited",
    image:
      "https://images.unsplash.com/photo-1584917865442-de89df76afd3?auto=format&fit=crop&w=800&q=80",
    description: "Tas structured dengan detail crown.",
  },
  {
    id: "bag-05",
    name: "Leather Noir Tote",
    category: "Luxury Bag",
    price: 9200000,
    discount: 6,
    rating: 4.5,
    reviews: 38,
    stock: 7,
    sku: "BAG-005",
    badge: "Best Seller",
    image:
      "https://images.unsplash.com/photo-1584917865442-de89df76afd3?auto=format&fit=crop&w=800&q=80",
    description: "Tote kulit noir premium.",
  },
  {
    id: "bag-06",
    name: "Pearl Evening Bag",
    category: "Luxury Bag",
    price: 8700000,
    discount: 5,
    rating: 4.7,
    reviews: 53,
    stock: 6,
    sku: "BAG-006",
    badge: "Hot",
    image:
      "https://images.unsplash.com/photo-1584917865442-de89df76afd3?auto=format&fit=crop&w=800&q=80",
    description: "Tas malam dengan aksen mutiara.",
  },
  {
    id: "watch-01",
    name: "Royal Chronograph",
    category: "Watch",
    price: 18500000,
    discount: 14,
    rating: 4.9,
    reviews: 104,
    stock: 3,
    sku: "WAT-001",
    badge: "Limited",
    image:
      "https://images.unsplash.com/photo-1523170335258-f5ed11844a49?auto=format&fit=crop&w=800&q=80",
    description: "Jam tangan chronograph mewah.",
  },
  {
    id: "watch-02",
    name: "Silver Prestige Watch",
    category: "Watch",
    price: 11200000,
    discount: 8,
    rating: 4.7,
    reviews: 59,
    stock: 5,
    sku: "WAT-002",
    badge: "Best Seller",
    image:
      "https://images.unsplash.com/photo-1523170335258-f5ed11844a49?auto=format&fit=crop&w=800&q=80",
    description: "Jam tangan silver prestige modern.",
  },
  {
    id: "watch-03",
    name: "Golden Hour Watch",
    category: "Watch",
    price: 13800000,
    discount: 9,
    rating: 4.8,
    reviews: 74,
    stock: 4,
    sku: "WAT-003",
    badge: "New",
    image:
      "https://images.unsplash.com/photo-1523170335258-f5ed11844a49?auto=format&fit=crop&w=800&q=80",
    description: "Watch golden hour eksklusif.",
  },
  {
    id: "watch-04",
    name: "Black Sapphire Watch",
    category: "Watch",
    price: 15400000,
    discount: 11,
    rating: 4.9,
    reviews: 92,
    stock: 3,
    sku: "WAT-004",
    badge: "Hot",
    image:
      "https://images.unsplash.com/photo-1523170335258-f5ed11844a49?auto=format&fit=crop&w=800&q=80",
    description: "Jam tangan black sapphire untuk tampilan berkelas.",
  },
  {
    id: "gift-01",
    name: "Gift Set Diamond Box",
    category: "Gift Collection",
    price: 4800000,
    discount: 7,
    rating: 4.6,
    reviews: 35,
    stock: 10,
    sku: "GIF-001",
    badge: "New",
    image:
      "https://images.unsplash.com/photo-1512436991641-6745cdb1723f?auto=format&fit=crop&w=800&q=80",
    description: "Set hadiah eksklusif berisi aksesori premium.",
  },
  {
    id: "gift-02",
    name: "Golden Keepsake Box",
    category: "Gift Collection",
    price: 3500000,
    discount: 5,
    rating: 4.4,
    reviews: 28,
    stock: 12,
    sku: "GIF-002",
    badge: "Best Seller",
    image:
      "https://images.unsplash.com/photo-1512436991641-6745cdb1723f?auto=format&fit=crop&w=800&q=80",
    description: "Kotak souvenir premium bertema gold.",
  },
  {
    id: "gift-03",
    name: "Luxury Ribbon Set",
    category: "Gift Collection",
    price: 2700000,
    discount: 4,
    rating: 4.5,
    reviews: 31,
    stock: 15,
    sku: "GIF-003",
    badge: "Hot",
    image:
      "https://images.unsplash.com/photo-1512436991641-6745cdb1723f?auto=format&fit=crop&w=800&q=80",
    description: "Set hadiah ribbon luxury untuk momen penting.",
  },
  {
    id: "gift-04",
    name: "Signature Gift Edition",
    category: "Gift Collection",
    price: 4100000,
    discount: 6,
    rating: 4.7,
    reviews: 42,
    stock: 9,
    sku: "GIF-004",
    badge: "Limited",
    image:
      "https://images.unsplash.com/photo-1512436991641-6745cdb1723f?auto=format&fit=crop&w=800&q=80",
    description: "Edisi hadiah signature untuk pelanggan premium.",
  },
];

PRODUCTS_DATA.forEach((product, index) => {
  product.image = getProductImage(product, index);
});

window.PRODUCTS_DATA = PRODUCTS_DATA;
